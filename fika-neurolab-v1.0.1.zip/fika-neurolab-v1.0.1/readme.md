# html-css-js
Aprendendo e desenvolvmento o meu primeiro site para um projeto de front-end para a faculdade.

Sempre amei criação de sites, inclusive já explorei antigamente bloggspot e tumblr para criação publicações para jogos. 
Estudar front-end foi uma expirẽncia muito satisfatória e fez eu retornar a ter essa paixão por criar sites.
O projeto Fika.........

<a hreft="https://severiano-mateus.github.io/fika-neurolab-unicsul/">Executar o arquivo html</a>
